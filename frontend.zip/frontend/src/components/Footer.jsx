import React from 'react'

const Footer = () => {
    return (
        <div style={{position: 'fixed', bottom:0, width:'100%'}}>
            <footer className='navbar navbar-expand-md navbar-dark bg-dark p-3'>
                
            </footer>
        </div>
    )
}

export default Footer;